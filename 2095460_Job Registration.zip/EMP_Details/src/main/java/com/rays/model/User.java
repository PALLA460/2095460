package com.rays.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	//@Column(name = "uname")
	private String userName;
	private String userPassword;
	private String  email;
	private Integer userAge;
	private String address;
	private String userCity;
	private String gender;
	private Long mobile;
	private String institution;
	private String branch; 
	private Double percentage;
	private String agree;
	
	@Lob
	private byte[] userPic;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
		}
		public User(Integer id, String userName, String userPassword,String Email, Integer userAge, String Address,
		String userCity,String gender,Long Mobile,String Institution, String Branch,Double Percentage,String Agree ) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.email = Email;
		this.userAge = userAge;
		this.address =Address;
		this.userCity = userCity;
		this.gender=gender;
		this.mobile=Mobile;
		this.institution = Institution;
		this.branch=Branch;
		this.percentage=Percentage;
		this.agree=Agree;
		this.userPic = userPic;

		}


		public User(Integer id, String userName, String userPassword,String Email, Integer userAge, String Address,
				String userCity,String gender,Long Mobile,String Institution, String Branch,
				Double Percentage,String Agree,byte[] userPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.email = Email;
		this.userAge = userAge;
		this.address =Address;
		this.userCity = userCity;
		this.gender=gender;
		this.mobile=Mobile;
		this.institution = Institution;
		this.branch=Branch;
		this.percentage=Percentage;
		this.agree=Agree;
		this.userPic = userPic;
		}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getUserAge() {
		return userAge;
	}

	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String adress) {
		address = adress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	public String getAgree() {
		return agree;
	}

	public void setAgree(String agree) {
		this.agree = agree;
	}

	public byte[] getUserPic() {
		return userPic;
	}

	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", Email=" + email
				+ ", userAge=" + userAge + ", Address=" + address + ", userCity=" + userCity + ", gender=" + gender
				+ ", Mobile=" + mobile + ", Institution=" + institution + ", Branch=" + branch + ", Percentage="
				+ percentage + ", agree=" + agree + ", userPic=" + Arrays.toString(userPic) + "]";
	}
	
	
	
	
	
}
